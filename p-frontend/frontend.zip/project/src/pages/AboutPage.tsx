import {
  MapPin,
  Clock,
  Award,
  Heart,
  Users,
  ShoppingBag,
  Star,
  ChevronRight,
  Target,
  Eye,
} from 'lucide-react';
import { BUSINESS } from '../lib/constants';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

function AnimatedSection({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const { ref, isVisible } = useScrollAnimation(0.1);
  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ${className}`}
      style={{
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
        transitionDelay: `${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

function HeroSection() {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-coral-50 via-blush-50 to-sunny-50" />
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-10 right-20 w-72 h-72 bg-coral-200 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-blush-200 rounded-full blur-3xl animate-float-delayed" />
      </div>
      <div className="relative container-max mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <span className="inline-block px-4 py-1.5 bg-white/80 backdrop-blur-sm text-coral-600 text-sm font-semibold rounded-full mb-6 border border-coral-100">
          Our Story
        </span>
        <h1 className="heading-display text-4xl sm:text-5xl lg:text-6xl text-gray-900 mb-6">
          About <span className="gradient-text">Laadla Kids Wear</span>
        </h1>
        <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
          A journey of {BUSINESS.yearsInBusiness} years in bringing smiles to children and peace of mind to parents through quality, style, and trust.
        </p>
      </div>
    </section>
  );
}

function StorySection() {
  return (
    <section className="section-padding bg-white">
      <div className="container-max mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <AnimatedSection>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-coral-200 to-blush-200 rounded-3xl rotate-3" />
              <div className="relative rounded-3xl overflow-hidden shadow-xl">
                <img
                  src="https://images.pexels.com/photos/1457801/pexels-photo-1457801.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Laadla Kids Wear store"
                  className="w-full h-[400px] object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-white rounded-2xl shadow-xl p-5">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-coral-100 rounded-xl flex items-center justify-center">
                    <Award className="w-6 h-6 text-coral-500" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-800">{BUSINESS.yearsInBusiness}+</p>
                    <p className="text-sm text-gray-500">Years in Business</p>
                  </div>
                </div>
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection delay={200}>
            <div className="space-y-6">
              <span className="inline-block px-4 py-1.5 bg-coral-50 text-coral-600 text-sm font-semibold rounded-full">
                Our Journey
              </span>
              <h2 className="heading-display text-3xl sm:text-4xl text-gray-900">
                From a Small Shop to <span className="gradient-text">Sikar's Favorite</span>
              </h2>
              <p className="text-gray-600 leading-relaxed">
                Founded in {BUSINESS.established} in the heart of Tabela Market, Laadla Kids Wear started with a simple mission: to provide parents in Sikar with stylish, high-quality readymade garments for their children. What began as a small retail outlet has grown into one of the most trusted names in children's fashion in the region.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Over {BUSINESS.yearsInBusiness} years, we have carefully curated our collection to include the finest brands like Lava Kids and Marks & Spencer, ensuring that every garment meets the highest standards of quality, comfort, and style. Our deep understanding of what local families need has helped us build lasting relationships with thousands of customers.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Today, Laadla Kids Wear is more than just a shop - it's a destination where parents can find everything their children need, from everyday wear to special occasion outfits, all under one roof.
              </p>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  );
}

function ValuesSection() {
  const values = [
    {
      icon: Heart,
      title: 'Quality First',
      description: 'Every garment is handpicked and quality-checked to ensure your children get the best.',
      color: 'coral',
    },
    {
      icon: Users,
      title: 'Customer Love',
      description: 'We treat every customer like family, offering personalized service and genuine care.',
      color: 'blush',
    },
    {
      icon: Star,
      title: 'Latest Trends',
      description: 'Our collection is always updated with the latest fashion trends for children.',
      color: 'sunny',
    },
    {
      icon: ShoppingBag,
      title: 'One-Stop Shop',
      description: 'From dresses to night suits, find everything your child needs in one place.',
      color: 'mint',
    },
  ];

  const colorMap: Record<string, { bg: string; text: string }> = {
    coral: { bg: 'bg-coral-50', text: 'text-coral-500' },
    blush: { bg: 'bg-blush-50', text: 'text-blush-500' },
    sunny: { bg: 'bg-sunny-50', text: 'text-sunny-500' },
    mint: { bg: 'bg-mint-50', text: 'text-mint-500' },
  };

  return (
    <section className="section-padding pastel-bg">
      <div className="container-max mx-auto">
        <AnimatedSection className="text-center mb-14">
          <span className="inline-block px-4 py-1.5 bg-blush-50 text-blush-600 text-sm font-semibold rounded-full mb-4">
            Our Values
          </span>
          <h2 className="heading-display text-3xl sm:text-4xl lg:text-5xl text-gray-900 mb-4">
            What We <span className="gradient-text">Stand For</span>
          </h2>
        </AnimatedSection>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((v, i) => {
            const Icon = v.icon;
            const colors = colorMap[v.color];
            return (
              <AnimatedSection key={v.title} delay={i * 100}>
                <div className="p-6 rounded-2xl bg-white shadow-sm border border-gray-100 card-hover text-center h-full">
                  <div className={`w-14 h-14 mx-auto mb-4 rounded-2xl ${colors.bg} flex items-center justify-center`}>
                    <Icon className={`w-7 h-7 ${colors.text}`} />
                  </div>
                  <h3 className="font-display font-semibold text-lg text-gray-800 mb-2">{v.title}</h3>
                  <p className="text-sm text-gray-500 leading-relaxed">{v.description}</p>
                </div>
              </AnimatedSection>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function VisionMissionSection() {
  return (
    <section className="section-padding bg-white">
      <div className="container-max mx-auto">
        <div className="grid md:grid-cols-2 gap-8">
          <AnimatedSection>
            <div className="p-8 rounded-2xl bg-gradient-to-br from-coral-50 to-blush-50 border border-coral-100 h-full">
              <div className="w-14 h-14 mb-4 rounded-2xl bg-coral-100 flex items-center justify-center">
                <Eye className="w-7 h-7 text-coral-500" />
              </div>
              <h3 className="font-display font-bold text-2xl text-gray-800 mb-3">Our Vision</h3>
              <p className="text-gray-600 leading-relaxed">
                To be the most trusted and loved destination for children's fashion in Rajasthan, known for quality, variety, and the joy we bring to every family that walks through our doors.
              </p>
            </div>
          </AnimatedSection>
          <AnimatedSection delay={150}>
            <div className="p-8 rounded-2xl bg-gradient-to-br from-sky-50 to-mint-50 border border-sky-100 h-full">
              <div className="w-14 h-14 mb-4 rounded-2xl bg-sky-100 flex items-center justify-center">
                <Target className="w-7 h-7 text-sky-500" />
              </div>
              <h3 className="font-display font-bold text-2xl text-gray-800 mb-3">Our Mission</h3>
              <p className="text-gray-600 leading-relaxed">
                To provide parents with easy access to premium, stylish, and comfortable readymade garments for their children, backed by exceptional service and unbeatable value.
              </p>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  );
}

function LocationSection() {
  return (
    <section className="section-padding pastel-bg">
      <div className="container-max mx-auto">
        <AnimatedSection className="text-center mb-14">
          <span className="inline-block px-4 py-1.5 bg-mint-50 text-mint-600 text-sm font-semibold rounded-full mb-4">
            Find Us
          </span>
          <h2 className="heading-display text-3xl sm:text-4xl lg:text-5xl text-gray-900 mb-4">
            Visit Our <span className="gradient-text">Store</span>
          </h2>
          <p className="text-gray-500 max-w-2xl mx-auto text-lg">
            Located in the heart of Tabela Market, Sikar - easy to find and hard to forget.
          </p>
        </AnimatedSection>

        <div className="grid lg:grid-cols-5 gap-8">
          <AnimatedSection className="lg:col-span-2 space-y-6">
            <div className="p-6 rounded-2xl bg-white shadow-sm border border-gray-100">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 rounded-xl bg-coral-50 flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6 text-coral-500" />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-lg text-gray-800 mb-1">Our Address</h3>
                  <p className="text-gray-600">{BUSINESS.address}</p>
                </div>
              </div>
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 rounded-xl bg-sky-50 flex items-center justify-center shrink-0">
                  <Clock className="w-6 h-6 text-sky-500" />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-lg text-gray-800 mb-1">Store Hours</h3>
                  <p className="text-gray-600">Monday - Saturday: 10:00 AM - 9:00 PM</p>
                  <p className="text-gray-600">Sunday: 11:00 AM - 7:00 PM</p>
                </div>
              </div>
              <a
                href={BUSINESS.mapLink}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary w-full text-center"
              >
                Get Directions
                <ChevronRight className="w-5 h-5 ml-1" />
              </a>
            </div>
          </AnimatedSection>

          <AnimatedSection className="lg:col-span-3" delay={200}>
            <div className="rounded-2xl overflow-hidden shadow-sm border border-gray-100 h-full min-h-[400px]">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3512.7!2d75.15!3d27.6!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjfCsDM2JzAwLjAiTiA3NcKwMDknMDAuMCJF!5e0!3m2!1sen!2sin!4v1"
                width="100%"
                height="100%"
                style={{ border: 0, minHeight: '400px' }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Laadla Kids Wear Location"
              />
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  );
}

export default function AboutPage() {
  return (
    <main>
      <HeroSection />
      <StorySection />
      <ValuesSection />
      <VisionMissionSection />
      <LocationSection />
    </main>
  );
}

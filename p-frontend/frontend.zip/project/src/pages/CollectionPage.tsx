import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Filter, ChevronDown, ArrowRight } from 'lucide-react';
import { CATEGORIES, BUSINESS } from '../lib/constants';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

function AnimatedSection({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const { ref, isVisible } = useScrollAnimation(0.1);
  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ${className}`}
      style={{
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
        transitionDelay: `${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

const COLLECTION_ITEMS: Record<string, Array<{ name: string; price: string; image: string; tag?: string }>> = {
  dresses: [
    { name: 'Floral Party Dress', price: 'Rs 699 - Rs 1,299', image: 'https://images.pexels.com/photos/1620761/pexels-photo-1620761.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'Bestseller' },
    { name: 'Cotton Summer Dress', price: 'Rs 499 - Rs 899', image: 'https://images.pexels.com/photos/1457800/pexels-photo-1457800.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Embroidered Festive Dress', price: 'Rs 899 - Rs 1,599', image: 'https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'New' },
    { name: 'Casual A-Line Dress', price: 'Rs 399 - Rs 799', image: 'https://images.pexels.com/photos/1598509/pexels-photo-1598509.jpeg?auto=compress&cs=tinysrgb&w=400' },
  ],
  'trousers-jeans': [
    { name: 'Denim Jeans - Classic Fit', price: 'Rs 599 - Rs 1,199', image: 'https://images.pexels.com/photos/1598508/pexels-photo-1598508.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'Popular' },
    { name: 'Cotton Chinos', price: 'Rs 499 - Rs 899', image: 'https://images.pexels.com/photos/1598509/pexels-photo-1598509.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Jogger Pants', price: 'Rs 399 - Rs 799', image: 'https://images.pexels.com/photos/1457801/pexels-photo-1457801.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'New' },
    { name: 'Formal Trousers', price: 'Rs 699 - Rs 1,299', image: 'https://images.pexels.com/photos/1620759/pexels-photo-1620759.jpeg?auto=compress&cs=tinysrgb&w=400' },
  ],
  'shirts-tops': [
    { name: 'Printed Cotton Shirt', price: 'Rs 349 - Rs 699', image: 'https://images.pexels.com/photos/1457801/pexels-photo-1457801.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'Bestseller' },
    { name: 'Graphic T-Shirt', price: 'Rs 249 - Rs 549', image: 'https://images.pexels.com/photos/1620761/pexels-photo-1620761.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Formal Shirt', price: 'Rs 499 - Rs 999', image: 'https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Stylish Crop Top', price: 'Rs 299 - Rs 599', image: 'https://images.pexels.com/photos/1457800/pexels-photo-1457800.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'New' },
  ],
  'cord-sets': [
    { name: 'Floral Cord Set', price: 'Rs 799 - Rs 1,499', image: 'https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'Trending' },
    { name: 'Denim Cord Set', price: 'Rs 899 - Rs 1,599', image: 'https://images.pexels.com/photos/1620761/pexels-photo-1620761.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Cotton Casual Set', price: 'Rs 599 - Rs 1,099', image: 'https://images.pexels.com/photos/1598508/pexels-photo-1598508.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Party Wear Set', price: 'Rs 999 - Rs 1,799', image: 'https://images.pexels.com/photos/1598509/pexels-photo-1598509.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'New' },
  ],
  suits: [
    { name: '3-Piece Party Suit', price: 'Rs 1,299 - Rs 2,499', image: 'https://images.pexels.com/photos/1598508/pexels-photo-1598508.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'Premium' },
    { name: '2-Piece Casual Suit', price: 'Rs 899 - Rs 1,699', image: 'https://images.pexels.com/photos/1620759/pexels-photo-1620759.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Ethnic 3-Piece Suit', price: 'Rs 1,499 - Rs 2,799', image: 'https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'Bestseller' },
    { name: 'Formal 2-Piece', price: 'Rs 999 - Rs 1,899', image: 'https://images.pexels.com/photos/1457801/pexels-photo-1457801.jpeg?auto=compress&cs=tinysrgb&w=400' },
  ],
  kuris: [
    { name: 'Embroidered Kuri', price: 'Rs 499 - Rs 999', image: 'https://images.pexels.com/photos/1457800/pexels-photo-1457800.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'Popular' },
    { name: 'Printed Cotton Kuri', price: 'Rs 349 - Rs 699', image: 'https://images.pexels.com/photos/1620761/pexels-photo-1620761.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Silk Festive Kuri', price: 'Rs 799 - Rs 1,499', image: 'https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'New' },
    { name: 'Casual Daily Wear Kuri', price: 'Rs 299 - Rs 599', image: 'https://images.pexels.com/photos/1598509/pexels-photo-1598509.jpeg?auto=compress&cs=tinysrgb&w=400' },
  ],
  'night-suits': [
    { name: 'Cotton Night Suit', price: 'Rs 399 - Rs 799', image: 'https://images.pexels.com/photos/1620759/pexels-photo-1620759.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'Comfort' },
    { name: 'Silk Night Dress', price: 'Rs 599 - Rs 1,099', image: 'https://images.pexels.com/photos/1598508/pexels-photo-1598508.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Kids Night Suit Set', price: 'Rs 349 - Rs 699', image: 'https://images.pexels.com/photos/1457801/pexels-photo-1457801.jpeg?auto=compress&cs=tinysrgb&w=400', tag: 'Bestseller' },
    { name: 'Women Night Gown', price: 'Rs 499 - Rs 999', image: 'https://images.pexels.com/photos/1620761/pexels-photo-1620761.jpeg?auto=compress&cs=tinysrgb&w=400' },
  ],
};

const TAG_COLORS: Record<string, string> = {
  Bestseller: 'bg-coral-500 text-white',
  New: 'bg-mint-500 text-white',
  Popular: 'bg-sky-500 text-white',
  Trending: 'bg-blush-500 text-white',
  Premium: 'bg-sunny-500 text-white',
  Comfort: 'bg-lavender-400 text-white',
};

export default function CollectionPage() {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  const filteredCategories = activeCategory
    ? CATEGORIES.filter((c) => c.id === activeCategory)
    : CATEGORIES;

  return (
    <main>
      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-coral-50 via-blush-50 to-sunny-50" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 right-20 w-72 h-72 bg-coral-200 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-10 left-10 w-96 h-96 bg-blush-200 rounded-full blur-3xl animate-float-delayed" />
        </div>
        <div className="relative container-max mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-block px-4 py-1.5 bg-white/80 backdrop-blur-sm text-coral-600 text-sm font-semibold rounded-full mb-6 border border-coral-100">
            Our Collection
          </span>
          <h1 className="heading-display text-4xl sm:text-5xl lg:text-6xl text-gray-900 mb-6">
            Explore Our <span className="gradient-text">Collection</span>
          </h1>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Discover a wide range of stylish readymade garments for children and women, featuring top brands like {BUSINESS.brands.join(' and ')}.
          </p>
        </div>
      </section>

      <section className="section-padding bg-white">
        <div className="container-max mx-auto">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-coral-500" />
              <span className="text-sm font-medium text-gray-600">
                {filteredCategories.length} {filteredCategories.length === 1 ? 'Category' : 'Categories'}
              </span>
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-4 py-2 rounded-full border border-gray-200 text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors sm:hidden"
            >
              <Filter className="w-4 h-4" />
              Filter
              <ChevronDown className={`w-4 h-4 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </button>
          </div>

          <div className={`${showFilters ? 'block' : 'hidden'} sm:block mb-8`}>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setActiveCategory(null)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  activeCategory === null
                    ? 'bg-coral-500 text-white shadow-md shadow-coral-200'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                All
              </button>
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                    activeCategory === cat.id
                      ? 'bg-coral-500 text-white shadow-md shadow-coral-200'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-16">
            {filteredCategories.map((cat, catIndex) => {
              const items = COLLECTION_ITEMS[cat.id] || [];
              return (
                <AnimatedSection key={cat.id} delay={catIndex * 100}>
                  <div>
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 rounded-xl bg-coral-50 flex items-center justify-center">
                        <ShoppingBag className="w-5 h-5 text-coral-500" />
                      </div>
                      <div>
                        <h2 className="font-display font-bold text-2xl text-gray-800">{cat.name}</h2>
                        <p className="text-sm text-gray-500">{cat.description}</p>
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
                      {items.map((item) => (
                        <div
                          key={item.name}
                          className="group rounded-2xl overflow-hidden bg-white border border-gray-100 card-hover"
                        >
                          <div className="relative h-56 overflow-hidden">
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                            />
                            {item.tag && (
                              <span className={`absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-semibold ${TAG_COLORS[item.tag] || 'bg-gray-500 text-white'}`}>
                                {item.tag}
                              </span>
                            )}
                          </div>
                          <div className="p-4">
                            <h3 className="font-semibold text-gray-800 mb-1">{item.name}</h3>
                            <p className="text-sm text-coral-600 font-medium">{item.price}</p>
                            <a
                              href={BUSINESS.social.whatsapp}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="mt-3 inline-flex items-center text-sm font-medium text-coral-500 hover:text-coral-700 transition-colors"
                            >
                              Enquire Now
                              <ArrowRight className="w-4 h-4 ml-1" />
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </AnimatedSection>
              );
            })}
          </div>

          <AnimatedSection className="mt-16 text-center">
            <div className="p-8 rounded-2xl bg-gradient-to-br from-coral-50 to-blush-50 border border-coral-100">
              <h3 className="font-display font-bold text-2xl text-gray-800 mb-3">
                Can't Find What You're Looking For?
              </h3>
              <p className="text-gray-600 mb-6 max-w-lg mx-auto">
                Our in-store collection is much larger. Visit us at Tabela Market, Sikar or message us on WhatsApp for specific enquiries.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link to="/contact" className="btn-primary">
                  Contact Us
                </Link>
                <a
                  href={BUSINESS.social.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-whatsapp"
                >
                  WhatsApp Enquiry
                </a>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>
    </main>
  );
}

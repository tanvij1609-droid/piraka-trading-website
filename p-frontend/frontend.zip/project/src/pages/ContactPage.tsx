import { useState } from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  MessageCircle,
  Send,
  CheckCircle,
  ChevronRight,
  Instagram,
  Facebook,
} from 'lucide-react';
import { BUSINESS } from '../lib/constants';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

function AnimatedSection({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const { ref, isVisible } = useScrollAnimation(0.1);
  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ${className}`}
      style={{
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
        transitionDelay: `${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

function HeroSection() {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-coral-50 via-blush-50 to-sunny-50" />
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-10 right-20 w-72 h-72 bg-coral-200 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-blush-200 rounded-full blur-3xl animate-float-delayed" />
      </div>
      <div className="relative container-max mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <span className="inline-block px-4 py-1.5 bg-white/80 backdrop-blur-sm text-coral-600 text-sm font-semibold rounded-full mb-6 border border-coral-100">
          Get in Touch
        </span>
        <h1 className="heading-display text-4xl sm:text-5xl lg:text-6xl text-gray-900 mb-6">
          Contact <span className="gradient-text">Us</span>
        </h1>
        <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
          We'd love to hear from you! Whether you have a question about our collection, need help finding the right outfit, or just want to say hello.
        </p>
      </div>
    </section>
  );
}

function ContactForm() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', email: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const whatsappMsg = `Hi! I'm ${form.name}.%0APhone: ${form.phone}%0AEmail: ${form.email}%0A%0A${form.message}`;
    window.open(`https://wa.me/${BUSINESS.whatsapp}?text=${whatsappMsg}`, '_blank');
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setForm({ name: '', phone: '', email: '', message: '' });
    }, 3000);
  };

  return (
    <AnimatedSection>
      <div className="p-6 sm:p-8 rounded-2xl bg-white shadow-sm border border-gray-100">
        <h2 className="font-display font-bold text-2xl text-gray-800 mb-2">Send Us a Message</h2>
        <p className="text-sm text-gray-500 mb-6">Fill out the form and we'll get back to you via WhatsApp.</p>

        {submitted ? (
          <div className="text-center py-12">
            <CheckCircle className="w-16 h-16 text-mint-500 mx-auto mb-4" />
            <h3 className="font-display font-bold text-xl text-gray-800 mb-2">Message Sent!</h3>
            <p className="text-gray-500">Your message has been forwarded via WhatsApp. We'll respond shortly.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Full Name
              </label>
              <input
                type="text"
                id="name"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-coral-300 focus:ring-2 focus:ring-coral-100 outline-none transition-all text-sm"
                placeholder="Your name"
              />
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                Phone Number
              </label>
              <input
                type="tel"
                id="phone"
                required
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-coral-300 focus:ring-2 focus:ring-coral-100 outline-none transition-all text-sm"
                placeholder="Your phone number"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email (Optional)
              </label>
              <input
                type="email"
                id="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-coral-300 focus:ring-2 focus:ring-coral-100 outline-none transition-all text-sm"
                placeholder="Your email address"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                Message
              </label>
              <textarea
                id="message"
                required
                rows={4}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-coral-300 focus:ring-2 focus:ring-coral-100 outline-none transition-all text-sm resize-none"
                placeholder="How can we help you?"
              />
            </div>
            <button type="submit" className="btn-primary w-full">
              <Send className="w-4 h-4 mr-2" />
              Send via WhatsApp
            </button>
          </form>
        )}
      </div>
    </AnimatedSection>
  );
}

function ContactInfo() {
  return (
    <AnimatedSection delay={200}>
      <div className="space-y-6">
        <div className="p-6 rounded-2xl bg-white shadow-sm border border-gray-100">
          <h3 className="font-display font-semibold text-lg text-gray-800 mb-4">Contact Information</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-coral-50 flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5 text-coral-500" />
              </div>
              <div>
                <p className="font-medium text-gray-800 text-sm">Address</p>
                <p className="text-sm text-gray-600">{BUSINESS.address}</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-sky-50 flex items-center justify-center shrink-0">
                <Phone className="w-5 h-5 text-sky-500" />
              </div>
              <div>
                <p className="font-medium text-gray-800 text-sm">Phone</p>
                <a href={`tel:${BUSINESS.phone}`} className="text-sm text-coral-600 hover:underline">
                  {BUSINESS.phone}
                </a>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-mint-50 flex items-center justify-center shrink-0">
                <Mail className="w-5 h-5 text-mint-500" />
              </div>
              <div>
                <p className="font-medium text-gray-800 text-sm">Email</p>
                <a href={`mailto:${BUSINESS.email}`} className="text-sm text-coral-600 hover:underline">
                  {BUSINESS.email}
                </a>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-sunny-50 flex items-center justify-center shrink-0">
                <Clock className="w-5 h-5 text-sunny-500" />
              </div>
              <div>
                <p className="font-medium text-gray-800 text-sm">Store Hours</p>
                <p className="text-sm text-gray-600">Mon - Sat: 10 AM - 9 PM</p>
                <p className="text-sm text-gray-600">Sunday: 11 AM - 7 PM</p>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-gradient-to-br from-green-50 to-mint-50 border border-green-100">
          <div className="flex items-center gap-3 mb-4">
            <MessageCircle className="w-6 h-6 text-green-600" />
            <h3 className="font-display font-semibold text-lg text-gray-800">Quick WhatsApp</h3>
          </div>
          <p className="text-sm text-gray-600 mb-4">
            Get instant responses! Message us directly on WhatsApp for enquiries, orders, or any questions.
          </p>
          <a
            href={BUSINESS.social.whatsapp}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-whatsapp w-full justify-center"
          >
            <MessageCircle className="w-4 h-4 mr-2" />
            Chat on WhatsApp
          </a>
        </div>

        <div className="p-6 rounded-2xl bg-white shadow-sm border border-gray-100">
          <h3 className="font-display font-semibold text-lg text-gray-800 mb-4">Follow Us</h3>
          <div className="flex gap-3">
            <a
              href={BUSINESS.social.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-xl bg-gradient-to-br from-coral-50 to-blush-50 flex items-center justify-center hover:from-coral-100 hover:to-blush-100 transition-colors"
              aria-label="Instagram"
            >
              <Instagram className="w-5 h-5 text-coral-500" />
            </a>
            <a
              href={BUSINESS.social.facebook}
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-xl bg-gradient-to-br from-sky-50 to-sky-100 flex items-center justify-center hover:from-sky-100 hover:to-sky-200 transition-colors"
              aria-label="Facebook"
            >
              <Facebook className="w-5 h-5 text-sky-500" />
            </a>
            <a
              href={BUSINESS.social.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-50 to-mint-50 flex items-center justify-center hover:from-green-100 hover:to-mint-100 transition-colors"
              aria-label="WhatsApp"
            >
              <MessageCircle className="w-5 h-5 text-green-500" />
            </a>
          </div>
        </div>
      </div>
    </AnimatedSection>
  );
}

function MapSection() {
  return (
    <section className="section-padding bg-white">
      <div className="container-max mx-auto">
        <AnimatedSection className="text-center mb-10">
          <span className="inline-block px-4 py-1.5 bg-coral-50 text-coral-600 text-sm font-semibold rounded-full mb-4">
            Find Us
          </span>
          <h2 className="heading-display text-3xl sm:text-4xl text-gray-900 mb-4">
            Visit <span className="gradient-text">Our Store</span>
          </h2>
        </AnimatedSection>

        <AnimatedSection>
          <div className="rounded-2xl overflow-hidden shadow-sm border border-gray-100">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3512.7!2d75.15!3d27.6!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjfCsDM2JzAwLjAiTiA3NcKwMDknMDAuMCJF!5e0!3m2!1sen!2sin!4v1"
              width="100%"
              height="450"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Laadla Kids Wear Location"
            />
          </div>
          <div className="mt-4 text-center">
            <a
              href={BUSINESS.mapLink}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary"
            >
              Open in Google Maps
              <ChevronRight className="w-5 h-5 ml-1" />
            </a>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

export default function ContactPage() {
  return (
    <main>
      <HeroSection />
      <section className="section-padding bg-white">
        <div className="container-max mx-auto">
          <div className="grid lg:grid-cols-5 gap-8">
            <div className="lg:col-span-3">
              <ContactForm />
            </div>
            <div className="lg:col-span-2">
              <ContactInfo />
            </div>
          </div>
        </div>
      </section>
      <MapSection />
    </main>
  );
}

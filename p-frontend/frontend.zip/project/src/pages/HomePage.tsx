import { Link } from 'react-router-dom';
import {
  Shield,
  Sparkles,
  Palette,
  Heart,
  ArrowRight,
  Star,
  ChevronRight,
  Award,
  TrendingUp,
  Users,
} from 'lucide-react';
import { BUSINESS, CATEGORIES, FEATURES, TESTIMONIALS } from '../lib/constants';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const ICON_MAP: Record<string, React.ElementType> = {
  Shield,
  Sparkles,
  Palette,
  Heart,
};

function AnimatedSection({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const { ref, isVisible } = useScrollAnimation(0.1);
  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ${className}`}
      style={{
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
        transitionDelay: `${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-coral-50 via-blush-50 to-sunny-50" />
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-20 left-10 w-72 h-72 bg-coral-200 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-blush-200 rounded-full blur-3xl animate-float-delayed" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-sunny-200 rounded-full blur-3xl animate-pulse-soft" />
      </div>

      <div className="relative container-max mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-coral-100 shadow-sm animate-fade-in">
              <Award className="w-4 h-4 text-coral-500" />
              <span className="text-sm font-medium text-coral-700">
                {BUSINESS.yearsInBusiness} Years of Excellence in Sikar
              </span>
            </div>

            <h1 className="heading-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-gray-900 leading-[1.1] animate-fade-in-up">
              Dress Your{' '}
              <span className="gradient-text">Little Stars</span>{' '}
              in Style
            </h1>

            <p className="text-lg sm:text-xl text-gray-600 leading-relaxed max-w-lg animate-fade-in-up animate-delay-200">
              {BUSINESS.tagline}. Discover premium readymade garments from top brands, curated with love for your children.
            </p>

            <div className="flex flex-wrap gap-4 animate-fade-in-up animate-delay-300">
              <Link to="/collection" className="btn-primary text-base">
                Explore Collection
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
              <a href={BUSINESS.social.whatsapp} target="_blank" rel="noopener noreferrer" className="btn-secondary text-base">
                Chat with Us
              </a>
            </div>

            <div className="flex items-center gap-6 pt-4 animate-fade-in-up animate-delay-400">
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {[...Array(4)].map((_, i) => (
                    <div
                      key={i}
                      className="w-8 h-8 rounded-full border-2 border-white bg-gradient-to-br from-coral-300 to-blush-300"
                      style={{ zIndex: 4 - i }}
                    />
                  ))}
                </div>
                <div className="text-sm">
                  <span className="font-semibold text-gray-800">5000+</span>
                  <span className="text-gray-500 ml-1">Happy Families</span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-sunny-400 text-sunny-400" />
                ))}
                <span className="text-sm font-semibold text-gray-800 ml-1">4.9</span>
              </div>
            </div>
          </div>

          <div className="relative hidden lg:block">
            <div className="relative w-full aspect-square max-w-lg mx-auto">
              <div className="absolute inset-0 bg-gradient-to-br from-coral-200 to-blush-200 rounded-3xl rotate-6 animate-float" />
              <div className="absolute inset-0 bg-gradient-to-br from-sunny-100 to-mint-100 rounded-3xl -rotate-3 animate-float-delayed" />
              <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="https://images.pexels.com/photos/1620761/pexels-photo-1620761.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Kids fashion collection"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-coral-900/20 to-transparent" />
              </div>
              <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-xl p-4 animate-bounce-soft">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-mint-100 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-mint-600" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Latest Trends</p>
                    <p className="text-sm font-bold text-gray-800">Always in Style</p>
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-xl p-4 animate-float">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-sunny-100 rounded-xl flex items-center justify-center">
                    <Users className="w-5 h-5 text-sunny-600" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Trusted by</p>
                    <p className="text-sm font-bold text-gray-800">5000+ Families</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function FeaturesSection() {
  return (
    <section className="section-padding bg-white">
      <div className="container-max mx-auto">
        <AnimatedSection className="text-center mb-14">
          <span className="inline-block px-4 py-1.5 bg-coral-50 text-coral-600 text-sm font-semibold rounded-full mb-4">
            Why Choose Us
          </span>
          <h2 className="heading-display text-3xl sm:text-4xl lg:text-5xl text-gray-900 mb-4">
            What Makes Us <span className="gradient-text">Special</span>
          </h2>
          <p className="text-gray-500 max-w-2xl mx-auto text-lg">
            A legacy of quality, trust, and style that has made us the go-to destination for kids fashion in Sikar.
          </p>
        </AnimatedSection>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {FEATURES.map((feature, i) => {
            const Icon = ICON_MAP[feature.icon] || Sparkles;
            return (
              <AnimatedSection key={feature.title} delay={i * 100}>
                <div className="group p-6 rounded-2xl bg-gradient-to-br from-gray-50 to-white border border-gray-100 card-hover text-center">
                  <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-coral-50 flex items-center justify-center group-hover:bg-coral-100 transition-colors">
                    <Icon className="w-7 h-7 text-coral-500" />
                  </div>
                  <h3 className="font-display font-semibold text-lg text-gray-800 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-gray-500 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </AnimatedSection>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function CategoriesPreview() {
  return (
    <section className="section-padding pastel-bg">
      <div className="container-max mx-auto">
        <AnimatedSection className="text-center mb-14">
          <span className="inline-block px-4 py-1.5 bg-blush-50 text-blush-600 text-sm font-semibold rounded-full mb-4">
            Our Collection
          </span>
          <h2 className="heading-display text-3xl sm:text-4xl lg:text-5xl text-gray-900 mb-4">
            Explore Our <span className="gradient-text">Categories</span>
          </h2>
          <p className="text-gray-500 max-w-2xl mx-auto text-lg">
            From everyday essentials to party wear, we have everything your little ones need.
          </p>
        </AnimatedSection>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORIES.slice(0, 6).map((cat, i) => (
            <AnimatedSection key={cat.id} delay={i * 80}>
              <Link
                to="/collection"
                className="group block rounded-2xl overflow-hidden bg-white shadow-sm card-hover"
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900/50 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="font-display font-semibold text-xl text-white mb-1">
                      {cat.name}
                    </h3>
                    <p className="text-sm text-white/80">{cat.description}</p>
                  </div>
                </div>
              </Link>
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection className="text-center mt-10">
          <Link to="/collection" className="btn-primary">
            View Full Collection
            <ChevronRight className="w-5 h-5 ml-1" />
          </Link>
        </AnimatedSection>
      </div>
    </section>
  );
}

function BrandsSection() {
  return (
    <section className="section-padding bg-white">
      <div className="container-max mx-auto">
        <AnimatedSection className="text-center mb-12">
          <span className="inline-block px-4 py-1.5 bg-sky-50 text-sky-600 text-sm font-semibold rounded-full mb-4">
            Premium Brands
          </span>
          <h2 className="heading-display text-3xl sm:text-4xl lg:text-5xl text-gray-900 mb-4">
            Brands We <span className="gradient-text">Carry</span>
          </h2>
          <p className="text-gray-500 max-w-2xl mx-auto text-lg">
            We partner with the finest brands to bring you quality you can trust.
          </p>
        </AnimatedSection>

        <div className="grid sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
          {BUSINESS.brands.map((brand, i) => (
            <AnimatedSection key={brand} delay={i * 150}>
              <div className="group p-8 rounded-2xl bg-gradient-to-br from-gray-50 to-white border border-gray-100 text-center card-hover">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-coral-100 to-blush-100 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Sparkles className="w-8 h-8 text-coral-500" />
                </div>
                <h3 className="font-display font-bold text-2xl text-gray-800 mb-2">{brand}</h3>
                <p className="text-sm text-gray-500">
                  Premium quality garments with international standards
                </p>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

function TestimonialsSection() {
  return (
    <section className="section-padding bg-gradient-to-br from-coral-50 via-blush-50 to-sunny-50">
      <div className="container-max mx-auto">
        <AnimatedSection className="text-center mb-14">
          <span className="inline-block px-4 py-1.5 bg-sunny-50 text-sunny-600 text-sm font-semibold rounded-full mb-4">
            Testimonials
          </span>
          <h2 className="heading-display text-3xl sm:text-4xl lg:text-5xl text-gray-900 mb-4">
            What Parents <span className="gradient-text">Say</span>
          </h2>
          <p className="text-gray-500 max-w-2xl mx-auto text-lg">
            Hear from the families who trust us for their children's wardrobe.
          </p>
        </AnimatedSection>

        <div className="grid md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, i) => (
            <AnimatedSection key={t.name} delay={i * 100}>
              <div className="p-6 rounded-2xl bg-white shadow-sm border border-gray-100 card-hover">
                <div className="flex gap-1 mb-4">
                  {[...Array(t.rating)].map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-sunny-400 text-sunny-400" />
                  ))}
                </div>
                <p className="text-gray-600 leading-relaxed mb-4 text-sm">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-coral-300 to-blush-300 flex items-center justify-center text-white font-bold text-sm">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-800 text-sm">{t.name}</p>
                    <p className="text-xs text-gray-400">Verified Customer</p>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="section-padding bg-white">
      <div className="container-max mx-auto">
        <AnimatedSection>
          <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-coral-500 to-blush-500 p-8 sm:p-12 lg:p-16">
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white rounded-full blur-3xl" />
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-white rounded-full blur-3xl" />
            </div>
            <div className="relative text-center max-w-2xl mx-auto">
              <h2 className="heading-display text-3xl sm:text-4xl lg:text-5xl text-white mb-4">
                Visit Our Store Today
              </h2>
              <p className="text-white/80 text-lg mb-8">
                Experience the collection in person. Our friendly staff will help you find the perfect outfit for your little ones.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link to="/contact" className="inline-flex items-center justify-center px-6 py-3 bg-white text-coral-600 font-semibold rounded-full hover:bg-gray-50 transition-colors">
                  Get Directions
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
                <a
                  href={BUSINESS.social.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center px-6 py-3 bg-green-500 text-white font-semibold rounded-full hover:bg-green-600 transition-colors"
                >
                  WhatsApp Us
                </a>
              </div>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

export default function HomePage() {
  return (
    <main>
      <HeroSection />
      <FeaturesSection />
      <CategoriesPreview />
      <BrandsSection />
      <TestimonialsSection />
      <CTASection />
    </main>
  );
}

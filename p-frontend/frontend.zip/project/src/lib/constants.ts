export const BUSINESS = {
  name: 'Laadla Kids Wear',
  tagline: 'Stylish Readymade Garments for Your Little Ones',
  phone: '+919876543210',
  whatsapp: '919876543210',
  email: 'laadlakidswear@gmail.com',
  address: 'Tabela Market, Sikar, Rajasthan 332001',
  mapUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3512.7!2d75.15!3d27.6!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjfCsDM2JzAwLjAiTiA3NcKwMDknMDAuMCJF!5e0!3m2!1sen!2sin!4v1',
  mapLink: 'https://maps.google.com/?q=Tabela+Market+Sikar+Rajasthan',
  yearsInBusiness: 16,
  established: 2008,
  brands: ['Lava Kids', 'Marks & Spencer'],
  social: {
    whatsapp: 'https://wa.me/919876543210',
    instagram: 'https://instagram.com/laadlakidswear',
    facebook: 'https://facebook.com/laadlakidswear',
  },
};

export const CATEGORIES = [
  {
    id: 'dresses',
    name: 'Dresses',
    description: 'Stylish readymade dresses for every occasion',
    image: 'https://images.pexels.com/photos/1620761/pexels-photo-1620761.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'blush',
  },
  {
    id: 'trousers-jeans',
    name: 'Trousers & Jeans',
    description: 'Comfortable bottoms for active kids',
    image: 'https://images.pexels.com/photos/1598509/pexels-photo-1598509.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'sky',
  },
  {
    id: 'shirts-tops',
    name: 'Shirts & Tops',
    description: 'Trendy tops and shirts for everyday style',
    image: 'https://images.pexels.com/photos/1457801/pexels-photo-1457801.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'mint',
  },
  {
    id: 'cord-sets',
    name: 'Cord Sets',
    description: 'Coordinated sets for a complete look',
    image: 'https://images.pexels.com/photos/1620760/pexels-photo-1620760.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'coral',
  },
  {
    id: 'suits',
    name: '2 & 3-Piece Suits',
    description: 'Elegant suits for special occasions',
    image: 'https://images.pexels.com/photos/1598508/pexels-photo-1598508.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'sunny',
  },
  {
    id: 'kuris',
    name: 'Kuris',
    description: 'Traditional and modern kuris for kids',
    image: 'https://images.pexels.com/photos/1457800/pexels-photo-1457800.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'lavender',
  },
  {
    id: 'night-suits',
    name: 'Night Suits',
    description: 'Cozy nightwear for women & kids',
    image: 'https://images.pexels.com/photos/1620759/pexels-photo-1620759.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'mint',
  },
];

export const FEATURES = [
  {
    icon: 'Shield',
    title: '16 Years of Trust',
    description: 'Serving Sikar families since 2008 with quality garments and reliable service.',
  },
  {
    icon: 'Sparkles',
    title: 'Premium Brands',
    description: 'Featuring top brands like Lava Kids and Marks & Spencer for assured quality.',
  },
  {
    icon: 'Palette',
    title: 'Vast Collection',
    description: 'From everyday wear to party outfits, find everything under one roof.',
  },
  {
    icon: 'Heart',
    title: 'Made with Love',
    description: 'Every garment is handpicked to ensure comfort and style for your little ones.',
  },
];

export const TESTIMONIALS = [
  {
    name: 'Sunita Sharma',
    text: 'I have been buying from Laadla for my kids for the past 8 years. The quality is always excellent and the variety is unmatched in Sikar.',
    rating: 5,
  },
  {
    name: 'Rajesh Agarwal',
    text: 'Best kids wear shop in Tabela Market. My children love the clothes from here. The staff is very helpful and the prices are reasonable.',
    rating: 5,
  },
  {
    name: 'Priya Joshi',
    text: 'I always find the latest trends for my kids at Laadla. The Marks & Spencer collection is wonderful. Highly recommended!',
    rating: 5,
  },
];

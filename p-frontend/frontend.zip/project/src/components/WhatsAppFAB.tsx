import { MessageCircle } from 'lucide-react';
import { BUSINESS } from '../lib/constants';

export default function WhatsAppFAB() {
  return (
    <a
      href={BUSINESS.social.whatsapp}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-green-500 rounded-full flex items-center justify-center shadow-lg shadow-green-300/40 hover:bg-green-600 hover:shadow-xl hover:scale-110 transition-all duration-300 animate-bounce-soft"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="w-7 h-7 text-white" />
    </a>
  );
}

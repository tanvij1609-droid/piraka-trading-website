import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ShoppingBag } from 'lucide-react';
import { BUSINESS } from '../lib/constants';

const NAV_LINKS = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About Us' },
  { to: '/collection', label: 'Collection' },
  { to: '/contact', label: 'Contact' },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-md shadow-sm'
          : 'bg-transparent'
      }`}
    >
      <div className="container-max mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-coral-400 to-blush-400 rounded-xl flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow">
              <ShoppingBag className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-lg sm:text-xl text-gray-800 leading-tight">
                {BUSINESS.name}
              </span>
              <span className="text-[10px] sm:text-xs text-coral-500 font-medium tracking-wider uppercase">
                Since {BUSINESS.established}
              </span>
            </div>
          </Link>

          <div className="hidden md:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  location.pathname === link.to
                    ? 'bg-coral-100 text-coral-700'
                    : 'text-gray-600 hover:text-coral-600 hover:bg-coral-50'
                }`}
              >
                {link.label}
              </Link>
            ))}
            <a
              href={BUSINESS.social.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="ml-3 btn-whatsapp text-sm py-2 px-4"
            >
              WhatsApp
            </a>
          </div>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 rounded-lg text-gray-600 hover:bg-coral-50 transition-colors"
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      <div
        className={`md:hidden transition-all duration-300 overflow-hidden ${
          isOpen ? 'max-h-80 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="bg-white/95 backdrop-blur-md border-t border-coral-100 px-4 py-3 space-y-1">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`block px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                location.pathname === link.to
                  ? 'bg-coral-100 text-coral-700'
                  : 'text-gray-600 hover:bg-coral-50'
              }`}
            >
              {link.label}
            </Link>
          ))}
          <a
            href={BUSINESS.social.whatsapp}
            target="_blank"
            rel="noopener noreferrer"
            className="block btn-whatsapp text-sm py-2 px-4 mt-2 text-center"
          >
            Message on WhatsApp
          </a>
        </div>
      </div>
    </nav>
  );
}

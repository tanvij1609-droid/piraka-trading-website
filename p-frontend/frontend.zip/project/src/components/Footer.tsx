import { Link } from 'react-router-dom';
import { ShoppingBag, MapPin, Phone, Mail, Clock, Instagram, Facebook } from 'lucide-react';
import { BUSINESS } from '../lib/constants';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container-max mx-auto section-padding pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-coral-400 to-blush-400 rounded-xl flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              <span className="font-display font-bold text-xl text-white">
                {BUSINESS.name}
              </span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed mb-4">
              {BUSINESS.tagline}. Serving families in Sikar with love and quality garments for over {BUSINESS.yearsInBusiness} years.
            </p>
            <div className="flex gap-3">
              <a
                href={BUSINESS.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-coral-500 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={BUSINESS.social.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-coral-500 transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-display font-semibold text-white text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {[
                { to: '/', label: 'Home' },
                { to: '/about', label: 'About Us' },
                { to: '/collection', label: 'Collection' },
                { to: '/contact', label: 'Contact Us' },
              ].map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-sm text-gray-400 hover:text-coral-400 transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display font-semibold text-white text-lg mb-4">Categories</h3>
            <ul className="space-y-2">
              {['Dresses', 'Trousers & Jeans', 'Shirts & Tops', 'Cord Sets', '2 & 3-Piece Suits', 'Kuris', 'Night Suits'].map((cat) => (
                <li key={cat}>
                  <Link
                    to="/collection"
                    className="text-sm text-gray-400 hover:text-coral-400 transition-colors"
                  >
                    {cat}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display font-semibold text-white text-lg mb-4">Contact Info</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-coral-400 mt-0.5 shrink-0" />
                <span className="text-sm text-gray-400">{BUSINESS.address}</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-coral-400 shrink-0" />
                <a href={`tel:${BUSINESS.phone}`} className="text-sm text-gray-400 hover:text-coral-400 transition-colors">
                  {BUSINESS.phone}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-coral-400 shrink-0" />
                <a href={`mailto:${BUSINESS.email}`} className="text-sm text-gray-400 hover:text-coral-400 transition-colors">
                  {BUSINESS.email}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-coral-400 shrink-0" />
                <span className="text-sm text-gray-400">Mon - Sat: 10 AM - 9 PM</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-gray-500">
            &copy; {new Date().getFullYear()} {BUSINESS.name}. All rights reserved.
          </p>
          <p className="text-xs text-gray-500">
            Tabela Market, Sikar, Rajasthan
          </p>
        </div>
      </div>
    </footer>
  );
}
